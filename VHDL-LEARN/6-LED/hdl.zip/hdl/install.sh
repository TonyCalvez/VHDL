#!/bin/bash

export LM_LICENSE_FILE=2100@licences3
module load electronique
vivado_init
vivado-mode tcl -source script.tcl
djtgcfg prog -d Nexys4DDR -i 0 -f SYNTH_OUTPUTS/top.bit